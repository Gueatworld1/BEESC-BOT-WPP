' Liga o bot em segundo plano (sem janela). Usado na inicializacao do Windows.
Set sh = CreateObject("WScript.Shell")
pasta = CreateObject("Scripting.FileSystemObject").GetParentFolderName(WScript.ScriptFullName)
If WScript.Arguments.Count > 0 Then WScript.Sleep 4000
If Not BotRodando() Then sh.Run "cmd /c """ & pasta & "\iniciar_bot.bat""", 0, False

Function BotRodando()
  On Error Resume Next
  Set x = CreateObject("MSXML2.ServerXMLHTTP.6.0")
  x.setTimeouts 2000, 2000, 2000, 2000
  x.Open "GET", "http://127.0.0.1:5000/api/ping", False
  x.Send
  BotRodando = (Err.Number = 0 And x.Status = 200)
End Function
