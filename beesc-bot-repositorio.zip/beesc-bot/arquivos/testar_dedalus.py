import sys, dedalus

pedido = " ".join(sys.argv[1:]) or "calculo 2 stewart edicao 5"
print("Pedido:", pedido)
print("Interpretação:", dedalus.interpretar(pedido))
print("-" * 60)
print(dedalus.buscar(pedido, debug=True))
