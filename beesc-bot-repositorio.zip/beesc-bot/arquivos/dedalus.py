import html, re, threading, time, unicodedata, requests
from concurrent.futures import ThreadPoolExecutor
from datetime import datetime
from bs4 import BeautifulSoup

# ====== CONFIGURAÇÃO ======
BASE = "https://dedalus.usp.br/F/"
# Trechos que identificam as bibliotecas de São Carlos na coluna "Biblioteca" do Dedalus.
# Rode o testar_dedalus.py e ajuste conforme o nome que aparecer lá.
BIBLIOTECAS_SC = ["eesc", "ifsc", "iqsc", "icmc", "sao carlos", "achille bassi"]
# A busca é feita só nas bases das bibliotecas de São Carlos e só em livros.
# Os códigos são descobertos sozinhos no formulário de busca do Dedalus; estes
# valores só são usados se a descoberta falhar.
BASES_SC = ["EESC", "ICMC", "IFSC", "IQSC"]
# Biblioteca preferida: mostrada sozinha quando tem exemplar disponível. As outras de
# São Carlos só aparecem se ela não tiver o livro ou se todos estiverem emprestados.
PREFERIDA = "eesc"
SO_LIVROS = True
POR_BASE = 6           # quantos títulos analisar de cada base
MAX_REGISTROS = 12     # limite total de títulos analisados por busca
MAX_TITULOS = 3        # quantos títulos mostrar na resposta
MAX_EXEMPLARES = 3     # quantas linhas de localização mostrar por título
CACHE_MIN = 10         # repete a mesma busca sem consultar o Dedalus por 10 min
PARALELO = 4           # quantos títulos são consultados ao mesmo tempo
SESSAO_MIN = 8         # reaproveita as sessões do Dedalus por até 8 min
TEMPO_LIMITE = 12      # segundos de espera por página do Dedalus
HEADERS = {"User-Agent": "BibliotecaEESC-WhatsApp/1.0 (biblioteca@eesc.usp.br)"}

PALAVRAS_IGNORADAS = {
    "quero", "queria", "gostaria", "preciso", "procuro", "procurando", "tem", "tem?",
    "voces", "vcs", "o", "a", "os", "as", "um", "uma", "de", "do", "da", "dos", "das",
    "livro", "livros", "exemplar", "por", "favor", "pfv", "pf", "e", "no", "na", "em",
    "disponivel", "disponiveis", "biblioteca", "autor", "titulo", "sobre", "pra", "para",
}
_cache = {}


def norm(texto):
    t = unicodedata.normalize("NFKD", texto or "").encode("ascii", "ignore").decode()
    t = re.sub(r"[^\w\s]", " ", t)
    return " ".join(t.lower().split())


def interpretar(pedido):
    """Separa o pedido em termos de busca, edição e volume."""
    t = norm(pedido)
    edicao = volume = None
    m = re.search(r"\b(\d+)\s*(?:a|o)?\s*(?:ed|edicao)\b", t) or re.search(r"\b(?:ed|edicao)\s*(\d+)\b", t)
    if m:
        edicao = m.group(1)
        t = t.replace(m.group(0), " ")
    m = re.search(r"\b(?:vol|volume|v)\s*(\d+)\b", t)
    if m:
        volume = m.group(1)
        t = t.replace(m.group(0), " ")
    palavras = [p for p in t.split() if p not in PALAVRAS_IGNORADAS]
    numeros = [p for p in palavras if p.isdigit()]
    if numeros and not volume:
        volume = numeros[0]          # "calculo 2" -> volume 2
    termos = " ".join(p for p in palavras if not p.isdigit())
    return termos, edicao, volume


SESSAO_RE = re.compile(r"https?://dedalus\.usp\.br/F/[A-Z0-9]{20,}-\d+")


def _abrir_sessao(debug=False):
    """O Dedalus (Aleph) trabalha com sessões: primeiro pega o endereço da sessão."""
    sessao = requests.Session()
    sessao.headers.update(HEADERS)
    r = _decodificar(sessao.get(BASE, timeout=TEMPO_LIMITE))
    m = SESSAO_RE.search(r.url) or SESSAO_RE.search(r.text)
    sessao.base = m.group(0) if m else BASE
    if debug:
        print(f"Sessão do Dedalus: {sessao.base}")
    return sessao


_pool, _pool_trava = {"sessoes": [], "criado": 0}, threading.Lock()


def _sessoes(debug=False):
    """Sessões do Dedalus reaproveitadas entre buscas (abrir uma sessão custa uma página).
    Cada consulta paralela usa a sua própria sessão."""
    with _pool_trava:
        if not _pool["sessoes"] or time.time() - _pool["criado"] > SESSAO_MIN * 60:
            with ThreadPoolExecutor(PARALELO) as ex:
                _pool["sessoes"] = list(ex.map(lambda _: _abrir_sessao(), range(PARALELO)))
            _pool["criado"] = time.time()
            if debug:
                print(f"{PARALELO} sessões do Dedalus abertas")
        return list(_pool["sessoes"])


def _descartar_sessoes():
    with _pool_trava:
        _pool["sessoes"] = []


def _decodificar(r):
    # o Dedalus nem sempre informa o charset; sem isso os acentos saem errados (Ã©, Ã£...)
    if "charset" not in r.headers.get("Content-Type", "").lower():
        r.encoding = "utf-8"
    return r


def _texto(sessao, **params):
    r = _decodificar(sessao.get(sessao.base, params=params, timeout=TEMPO_LIMITE))
    r.raise_for_status()
    # às vezes o Aleph responde só com um redirecionamento por meta/JavaScript
    m = re.search(r"(?:URL=|location\s*=\s*['\"])(https?://dedalus\.usp\.br/F/[^'\"\s>]+)", r.text, re.I)
    if m and len(r.text) < 4000:
        r = _decodificar(sessao.get(html.unescape(m.group(1)), timeout=TEMPO_LIMITE))
    return r.text


def _pagina(sessao, **params):
    return BeautifulSoup(_texto(sessao, **params), "html.parser")


_codigos = {}


def _descobrir_codigos(sessao, debug=False):
    """Lê o formulário de busca simples do Dedalus e descobre:
    - os códigos das bases das bibliotecas de São Carlos (lista "Base para busca");
    - o código do filtro "Tipo de material" e o valor que significa "Livros"."""
    if _codigos:
        return _codigos
    bases, filtro_livro = [], None
    try:
        txt = _texto(sessao, func="find-b-0")
        if debug:
            with open("dedalus_debug_formulario.html", "w", encoding="utf-8") as f:
                f.write(txt)
        pag = BeautifulSoup(txt, "html.parser")
        sel = pag.find("select", attrs={"name": "local_base"})
        if sel:
            for o in sel.find_all("option"):
                rotulo = o.get_text(" ", strip=True) + " " + (o.get("value") or "")
                if o.get("value") and _eh_sao_carlos(rotulo):
                    bases.append(o["value"])
                    if PREFERIDA in norm(rotulo):
                        _codigos["base_pref"] = o["value"]
        for sel in pag.find_all("select", attrs={"name": re.compile(r"^filter_request_\d+$")}):
            n = sel["name"].rsplit("_", 1)[1]
            cod = pag.find("input", attrs={"name": f"filter_code_{n}"})
            for o in sel.find_all("option"):
                if o.get("value") and norm(o.get_text()).startswith("livro"):
                    filtro_livro = (n, cod.get("value") if cod else None, o["value"])
                    break
            if filtro_livro:
                break
        if debug:
            print(f"Bases de São Carlos encontradas no formulário: {bases or 'nenhuma'} | preferida: {_codigos.get('base_pref')}")
            print(f"Filtro de livros: {filtro_livro or 'não encontrado'}")
    except requests.RequestException:
        pass
    _codigos["bases"] = bases or BASES_SC
    _codigos["livro"] = filtro_livro
    return _codigos


def _docs_da_busca(sessao, termos, debug=False, base="USP01", limite=None):
    limite = limite or MAX_REGISTROS
    params = dict(func="find-b", local_base=base, find_code="WRD", request=termos, adjacent="N")
    livro = _codigos.get("livro")
    if SO_LIVROS and livro and livro[1]:
        params[f"filter_code_{livro[0]}"] = livro[1]
        params[f"filter_request_{livro[0]}"] = livro[2]
    txt = _texto(sessao, **params)
    if debug:
        with open(f"dedalus_debug_busca_{base}.html", "w", encoding="utf-8") as f:
            f.write(txt)
        titulo = re.search(r"<title>(.*?)</title>", txt, re.S | re.I)
        print(f"Busca na base {base}: '{titulo.group(1).strip() if titulo else '?'}' ({len(txt)} caracteres)")
    docs = re.findall(r"doc_number=(\d+)", txt)
    if not docs:  # lista de resultados sem doc_number: abre cada resultado
        conjunto = re.search(r"set_number=(\d+)", txt)
        entradas = sorted(set(re.findall(r"set_entry=(\d+)", txt)))[:limite]
        if debug:
            print(f"Sem doc_number na lista; set_number={conjunto.group(1) if conjunto else None}, "
                  f"{len(entradas)} resultado(s)")
        if conjunto:
            for e in entradas:
                t2 = _texto(sessao, func="full-set-set", set_number=conjunto.group(1), set_entry=e, format="999")
                d = re.findall(r"doc_number=(\d+)", t2)
                if d:
                    docs.append(d[0])
    return [d.zfill(9) for d in dict.fromkeys(docs)][:limite]


def _limpar_marc(valor):
    valor = re.sub(r"(\$\$|\|)[a-z0-9]\s?", " ", valor)
    return " ".join(valor.split()).strip(" /:;,.")


ROTULOS = {"titulo": "245", "autor": "100", "edicao": "250", "imprenta": "260", "publicacao": "264"}


def _dados_do_registro(sessao, doc, debug=False):
    txt = _texto(sessao, func="direct", local_base="USP01", doc_number=doc, format="999")
    if debug and not getattr(sessao, "registro_salvo", False):
        with open("dedalus_debug_registro.html", "w", encoding="utf-8") as f:
            f.write(txt)
        sessao.registro_salvo = True
    campos = {}
    for tr in BeautifulSoup(txt, "html.parser").find_all("tr"):
        tds = [td.get_text(" ", strip=True) for td in tr.find_all("td")]
        if len(tds) < 2 or not tds[-1]:
            continue
        rotulo = norm(tds[0])
        tag = rotulo[:3] if rotulo[:3].isdigit() else next((t for r, t in ROTULOS.items() if rotulo.startswith(r)), None)
        if tag in ("100", "245", "250", "260", "264") and tag not in campos:
            campos[tag] = _limpar_marc(tds[-1])   # o conteúdo fica na última coluna
    ano = re.search(r"(1[89]|20)\d\d", campos.get("264", "") or campos.get("260", ""))
    return {
        "titulo": campos.get("245", "(sem título)").split(" / ")[0],
        "autor": campos.get("100", ""),
        "edicao": campos.get("250", ""),
        "ano": ano.group(0) if ano else "",
    }


def _celula(td):
    """Texto da célula. A localização vem dentro de um script (var url0700 = '001.535&nbsp;X6a')."""
    script = td.find("script")
    if script:
        m = re.search(r"url\d*\s*=\s*'([^']*)'", script.get_text())
        if m:
            return " ".join(html.unescape(m.group(1)).split())
    return td.get_text(" ", strip=True)


def _coluna(cabecalho, *chaves):
    for i, nome in enumerate(cabecalho):
        if any(c in nome for c in chaves):
            return i
    return None


COLUNAS_EXEMPLAR = ("chamada", "status", "situa", "devolu", "localiz", "colec", "barras")


def _ler_tabela(txt, debug=False):
    """Lê a tabela de exemplares de uma página item-global."""
    for tabela in BeautifulSoup(txt, "html.parser").find_all("table"):
        linhas = tabela.find_all("tr", recursive=False) or tabela.find_all("tr")
        # procura a linha de cabeçalho da tabela de exemplares: precisa ter "biblioteca",
        # "status" e "emprestado até"/"localização". Isso descarta o formulário de filtro
        # ("Selecione...") e faixas de título como "Biblioteca IQSC | Coleção".
        cab, inicio = None, 0
        for n, tr in enumerate(linhas[:3]):
            c = [norm(x.get_text(" ", strip=True)) for x in tr.find_all(["th", "td"])]
            j = " ".join(c)
            if "selecione" not in j and "biblioteca" in j and "status" in j and any(k in j for k in ("emprestado", "devolu", "localiz", "chamada")):
                cab, inicio = c, n
                break
        if not cab:
            continue
        linhas = linhas[inicio:]
        c_bib = _coluna(cab, "biblioteca")
        c_cham = _coluna(cab, "chamada", "localiz")
        c_stat = _coluna(cab, "status", "situa")
        c_dev = _coluna(cab, "devolu", "emprestado ate")
        c_desc = _coluna(cab, "descri")
        if debug:
            print(f"   colunas do exemplar: {cab}")
        itens = []
        for tr in linhas[1:]:
            cel = [_celula(c) for c in tr.find_all("td")]
            pega = lambda i: cel[i] if i is not None and i < len(cel) else ""
            if not cel or not pega(c_bib):
                continue
            itens.append({
                "biblioteca": pega(c_bib), "chamada": pega(c_cham), "status": pega(c_stat),
                "devolucao": pega(c_dev), "descricao": pega(c_desc), "linha": " | ".join(cel),
            })
        return itens
    return []


def _eh_sao_carlos(nome):
    return any(b in norm(nome) for b in BIBLIOTECAS_SC)


def _bibliotecas_do_livro(sessao, doc, debug=False):
    """Lê o filtro "Sub-biblioteca" da lista de exemplares, que mostra todas as
    bibliotecas da USP com o livro. Devolve ({código: nome} de São Carlos, siglas das outras).
    A lista do Dedalus é paginada, por isso os exemplares são pedidos depois, já filtrados."""
    txt = _texto(sessao, func="item-global", doc_library="USP01", doc_number=doc)
    if debug and not getattr(sessao, "exemplares_salvo", False):
        with open("dedalus_debug_exemplares.html", "w", encoding="utf-8") as f:
            f.write(txt)
        sessao.exemplares_salvo = True
    filtro = BeautifulSoup(txt, "html.parser").find("select", attrs={"name": "sub_library"})
    if not filtro:
        return None, txt
    bibliotecas = [(o.get("value"), o.get_text(strip=True)) for o in filtro.find_all("option") if o.get("value")]
    sc = {cod: nome for cod, nome in bibliotecas if _eh_sao_carlos(nome)}
    outras = {nome.split("-")[0].strip() for cod, nome in bibliotecas if cod not in sc}
    if debug:
        print(f"   bibliotecas com o livro: {[c for c, _ in bibliotecas]} | São Carlos: {list(sc)}")
    return sc, outras


def _itens_da_biblioteca(sessao, doc, cod, debug=False):
    pagina = _texto(sessao, func="item-global", doc_library="USP01", doc_number=doc, sub_library=cod)
    lidos = [i for i in _ler_tabela(pagina, debug) if _eh_sao_carlos(i["biblioteca"])]
    if debug and not lidos and not getattr(sessao, "filtrada_salva", False):
        with open("dedalus_debug_exemplares_filtrado.html", "w", encoding="utf-8") as f:
            f.write(pagina)
        sessao.filtrada_salva = True
        print(f"   nenhum exemplar lido na página filtrada ({cod}); salva em dedalus_debug_exemplares_filtrado.html")
    return lidos


SUB_PREFERIDA = "EESC"   # código da EESC no filtro "Sub-biblioteca" do Dedalus


def _ler_filtro(txt):
    """Bibliotecas listadas no filtro "Sub-biblioteca": ({código: nome} de São Carlos, siglas das outras)."""
    filtro = BeautifulSoup(txt, "html.parser").find("select", attrs={"name": "sub_library"})
    if not filtro:
        return None, None
    bibliotecas = [(o.get("value"), o.get_text(strip=True)) for o in filtro.find_all("option") if o.get("value")]
    sc = {cod: nome for cod, nome in bibliotecas if _eh_sao_carlos(nome)}
    return sc, {nome.split("-")[0].strip() for cod, nome in bibliotecas if cod not in sc}


def _exemplares(sessao, doc, debug=False, volume=None):
    """Devolve (exemplares a mostrar, siglas de bibliotecas fora de São Carlos, tem EESC disponível).

    Regra: se a EESC tem exemplar disponível, mostra só ela. Se ela não tem o livro,
    ou todos estão emprestados, inclui as outras bibliotecas de São Carlos.
    Para ganhar tempo, a primeira página já vem filtrada pela EESC: ela traz os
    exemplares da EESC e, no filtro, a lista de todas as bibliotecas que têm o livro."""
    def do_volume(itens):
        if not volume:
            return itens
        filtrados = [i for i in itens if re.search(rf"\bv\s*{volume}\b", norm(i["descricao"] + " " + i["chamada"]))]
        return filtrados or itens

    pagina = _texto(sessao, func="item-global", doc_library="USP01", doc_number=doc, sub_library=SUB_PREFERIDA)
    sc, outras = _ler_filtro(pagina)
    if sc is None:  # sem o filtro nessa página: faz do jeito completo
        sc, outras = _bibliotecas_do_livro(sessao, doc, debug)
        if sc is None:
            todos = _ler_tabela(outras, debug)
            itens = [i for i in todos if _eh_sao_carlos(i["biblioteca"])]
            return itens, {i["biblioteca"].split("-")[0].strip() for i in todos if i not in itens}, False
        pagina = None
    if debug:
        print(f"   {doc}: bibliotecas de São Carlos com o livro: {list(sc)}")

    preferidas = [c for c, nome in sc.items() if PREFERIDA in norm(c + " " + nome)]
    itens = []
    for cod in preferidas:
        if pagina is not None and cod == SUB_PREFERIDA:
            itens += [i for i in _ler_tabela(pagina, debug) if _eh_sao_carlos(i["biblioteca"])]
        else:
            itens += _itens_da_biblioteca(sessao, doc, cod, debug)
    itens = do_volume(itens)
    pref_disponivel = any(_disponivel(i) for i in itens)
    if not pref_disponivel:
        for cod in sc:
            if cod not in preferidas:
                itens += do_volume(_itens_da_biblioteca(sessao, doc, cod, debug))
    return itens, outras, pref_disponivel


def _data(texto):
    m = re.search(r"(\d{2})/(\d{2})/(\d{2,4})", texto)
    if not m:
        return None, ""
    d, mes, a = m.groups()
    ano = int(a) + 2000 if len(a) == 2 else int(a)
    try:
        return datetime(ano, int(mes), int(d)), m.group(0)
    except ValueError:
        return None, m.group(0)


def _disponivel(item):
    # no Dedalus, "Emprestado até" vazio = exemplar na estante
    dev = norm(item["devolucao"])
    return dev == "" or "dispon" in dev or "estante" in dev


def _situacao(item):
    """Situação curta de um exemplar emprestado/indisponível."""
    data, texto_data = _data(item["devolucao"])
    if re.sub(r"[\d/\s]", "", item["devolucao"]):
        return item["devolucao"]                     # texto do Dedalus, ex.: "Esperado em 01/11/24"
    if data and data.date() < datetime.now().date():
        return "emprestado (atrasado)"
    if data:
        return f"emprestado até {texto_data[:5]}"
    return "indisponível"


def _formatar_grupo(itens):
    """Uma linha por biblioteca + localização, juntando exemplares iguais."""
    i0 = itens[0]
    sigla = i0["biblioteca"].split("-")[0].strip()          # "EESC-Esc. Eng. S. Carlos" -> "EESC"
    local = i0["chamada"] or "ver no balcão"
    if i0["descricao"] and norm(i0["descricao"]) not in norm(local):   # evita "v.1 v.1"
        local += " " + i0["descricao"]
    disp = [i for i in itens if _disponivel(i)]
    if disp:
        consulta = any(p in norm(i["status"]) for i in disp for p in ("consulta", "nao circula", "referencia"))
        sit = "✅ disponível" if len(itens) == 1 else f"✅ {len(disp)} de {len(itens)} disponíveis"
        sit += " (só consulta)" if consulta else ""
    else:
        sit = "⏳ " + _situacao(itens[0])
    return f"📍 {sigla} · *{local}* · {sit}"


def _formatar_titulo(dados, itens):
    titulo = dados["titulo"].split(" : ")[0].strip(" .")
    ed = re.search(r"\d+", dados["edicao"] or "")
    extra = ", ".join(p for p in [f"{ed.group(0)}ª ed." if ed else "", dados["ano"]] if p)
    grupos = {}
    for i in itens:
        # "621.3816 S449c.8 e.1", "e.2"... são exemplares da mesma estante: junta numa linha só
        i["chamada"] = re.sub(r"\s+e\.\s*\d+$", "", i["chamada"])
        grupos.setdefault((i["biblioteca"], i["chamada"], i["descricao"]), []).append(i)
    linhas = [f"📘 *{titulo}*" + (f" ({extra})" if extra else "")]
    linhas += [_formatar_grupo(g) for g in list(grupos.values())[:MAX_EXEMPLARES]]
    return "\n".join(linhas)


def buscar(pedido, debug=False):
    termos, edicao, volume = interpretar(pedido)
    if not termos:
        return "Não entendi o título. Envie o nome do livro e o autor, por exemplo: _Cálculo Stewart 5ª edição volume 2_."

    chave = (termos, edicao, volume)
    if chave in _cache and time.time() - _cache[chave][0] < CACHE_MIN * 60:
        return _cache[chave][1]

    if debug:
        print(f"Termos: '{termos}' | edição: {edicao} | volume: {volume}")
    inicio = time.time()
    try:
        sessoes = _sessoes(debug)
        sessao = sessoes[0]
        codigos = _descobrir_codigos(sessao, debug)
    except requests.RequestException:
        _descartar_sessoes()
        raise
    bases = codigos["bases"]
    base_pref = [codigos["base_pref"]] if codigos.get("base_pref") else [b for b in bases if PREFERIDA in norm(b)]
    outras_bases = [b for b in bases if b not in base_pref]

    resultados, vistos = [], set()
    outras = set()   # bibliotecas fora de São Carlos que têm o livro

    def analisar_um(doc, sess):
        try:
            return _analisar_um(doc, sess)
        except requests.RequestException as erro:
            if debug:
                print(f" {doc}: falhou ({erro})")
            return None, set()

    def _analisar_um(doc, sess):
        itens, outras_doc, pref_disp = _exemplares(sess, doc, debug, volume)
        if not itens:
            return None, outras_doc
        dados = _dados_do_registro(sess, doc, debug)
        if debug:
            print(f" {doc}: {dados['titulo']} | {dados['edicao']} | {len(itens)} exemplar(es) | EESC disponível: {pref_disp}")
        ed_ok = bool(edicao) and re.search(r"\d+", dados["edicao"] or "") is not None \
            and re.search(r"\d+", dados["edicao"]).group(0) == edicao
        tem_disp = any(_disponivel(i) for i in itens)
        return (ed_ok * 4 + pref_disp * 2 + tem_disp, dados, itens, ed_ok, pref_disp), outras_doc

    def suficiente():
        # já há títulos da EESC disponíveis (na edição pedida) para preencher a resposta
        return sum(1 for r in resultados if r[4] and (r[3] or not edicao)) >= MAX_TITULOS

    def analisar(docs):
        novos = [d for d in docs if d not in vistos][:max(0, MAX_REGISTROS - len(vistos))]
        vistos.update(novos)
        # analisa em lotes, cada título do lote na sua própria sessão, ao mesmo tempo
        with ThreadPoolExecutor(len(sessoes)) as ex:
            for i in range(0, len(novos), len(sessoes)):
                lote = novos[i:i + len(sessoes)]
                for res, fora in ex.map(analisar_um, lote, sessoes):
                    outras.update(fora or set())
                    if res:
                        resultados.append(res)
                if suficiente():
                    break

    def docs_da_base(base, limite, sess):
        try:
            docs = _docs_da_busca(sess, termos, debug, base=base, limite=limite)
        except requests.RequestException:
            docs = []
        if debug:
            print(f"   {base}: {len(docs)} registro(s)")
        return docs

    # 1) primeiro, só o acervo da EESC
    for base in base_pref:
        docs = docs_da_base(base, MAX_REGISTROS, sessao)
        if not docs and time.time() - _pool["criado"] > 60:
            # pode ser sessão vencida no Dedalus: abre sessões novas e tenta uma vez mais
            _descartar_sessoes()
            sessoes[:] = _sessoes(debug)
            sessao = sessoes[0]
            docs = docs_da_base(base, MAX_REGISTROS, sessao)
        analisar(docs)

    # 2) a EESC não tem disponível (ou não tem o livro): busca nas outras bases de São Carlos ao mesmo tempo
    if not any(r[4] and (r[3] or not edicao) for r in resultados) and outras_bases:
        with ThreadPoolExecutor(len(sessoes)) as ex:
            listas = list(ex.map(lambda par: docs_da_base(par[0], POR_BASE, par[1]),
                                 zip(outras_bases, sessoes * len(outras_bases))))
        intercalados = []
        for grupo in zip(*[l + [None] * (POR_BASE - len(l)) for l in listas]):
            intercalados += [d for d in grupo if d and d not in intercalados]
        analisar(intercalados)

    # 3) nada em São Carlos: procura no catálogo geral para dizer onde o livro está
    if not resultados:
        outras = set()
        docs = _docs_da_busca(sessao, termos, debug, base="USP01", limite=PARALELO)
        with ThreadPoolExecutor(len(sessoes)) as ex:
            for sc, fora in ex.map(lambda d, s: _bibliotecas_do_livro(s, d, debug), docs, sessoes):
                if sc is not None:
                    outras.update(fora)
    if debug:
        print(f"Tempo da busca: {time.time() - inicio:.1f} s")

    if not resultados and outras:
        siglas = sorted(outras)
        texto = (f"🔎 Não há em São Carlos. Está em: {', '.join(siglas[:8])}.\n"
                 "Peça pelo EEB (*3*) ou fale com a equipe (*atendimento*).")
    elif not resultados:
        texto = "🔎 Não encontrei esse livro na USP. Confira o título e o autor."
    else:
        # a EESC tem o livro pedido disponível: mostra só os títulos da EESC
        if any(r[4] and (r[3] or not edicao) for r in resultados):
            resultados = [r for r in resultados if r[4]]
        resultados.sort(key=lambda r: r[0], reverse=True)
        blocos = []
        if edicao and not resultados[0][3]:
            blocos.append(f"Não há a {edicao}ª ed. em São Carlos. Opções próximas:")
        blocos += [_formatar_titulo(d, itens) for _, d, itens, *_ in resultados[:MAX_TITULOS]]
        texto = "\n\n".join(blocos)

    texto += "\n\n_*9* nova busca · *menu* voltar_"
    _cache[chave] = (time.time(), texto)
    return texto
