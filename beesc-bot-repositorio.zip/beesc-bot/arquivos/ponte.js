// Ponte entre o WhatsApp e o bot em Python.
// Conecta ao WhatsApp (como um aparelho conectado), repassa as mensagens
// recebidas para o bot.py e envia as respostas que o bot.py pedir.
import makeWASocket, { useMultiFileAuthState, DisconnectReason, fetchLatestBaileysVersion, Browsers } from 'baileys'
import QRCode from 'qrcode'
import pino from 'pino'
import http from 'node:http'
import fs from 'node:fs'

const PORTA = 3000                                  // painel da ponte: http://localhost:3000
const BOT_URL = 'http://127.0.0.1:5000/webhook'     // onde o bot.py recebe as mensagens
const PASTA_LOGIN = 'auth'                          // sessão do WhatsApp (não compartilhe esta pasta)

let sock = null
let qrAtual = null
let conectado = false

function hora () { return new Date().toLocaleTimeString('pt-BR') }

async function conectar () {
  const { state, saveCreds } = await useMultiFileAuthState(PASTA_LOGIN)
  let version
  try { ({ version } = await fetchLatestBaileysVersion()) } catch { /* usa a versão padrão */ }

  sock = makeWASocket({
    version,
    auth: state,
    logger: pino({ level: 'silent' }),
    browser: Browsers.windows('Desktop'),
    markOnlineOnConnect: false,   // mantém as notificações chegando no celular
    syncFullHistory: false
  })

  sock.ev.on('creds.update', saveCreds)

  sock.ev.on('connection.update', async ({ connection, lastDisconnect, qr }) => {
    if (qr) {
      qrAtual = qr
      conectado = false
      console.log(`[${hora()}] Escaneie o QR code: abra http://localhost:${PORTA} no navegador`)
      console.log(await QRCode.toString(qr, { type: 'terminal', small: true }))
    }
    if (connection === 'open') {
      conectado = true
      qrAtual = null
      console.log(`[${hora()}] WhatsApp conectado.`)
    }
    if (connection === 'close') {
      conectado = false
      const codigo = lastDisconnect?.error?.output?.statusCode
      if (codigo === DisconnectReason.loggedOut) {
        console.log(`[${hora()}] O aparelho foi desconectado pelo celular. Gerando um novo QR code...`)
        fs.rmSync(PASTA_LOGIN, { recursive: true, force: true })
      } else {
        console.log(`[${hora()}] Conexão caiu (código ${codigo ?? '?'}). Reconectando...`)
      }
      setTimeout(conectar, 3000)
    }
  })

  sock.ev.on('messages.upsert', async ({ messages, type }) => {
    if (type !== 'notify') return
    for (const m of messages) {
      let msg = m.message
      if (!msg) continue
      msg = msg.ephemeralMessage?.message || msg.viewOnceMessageV2?.message || msg
      try {
        await fetch(BOT_URL, {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ data: { key: m.key, message: msg, pushName: m.pushName } })
        })
      } catch {
        console.log(`[${hora()}] O bot.py não respondeu. Ele está aberto?`)
      }
    }
  })
}

function lerCorpo (req) {
  return new Promise((resolve) => {
    let dados = ''
    req.on('data', (c) => { dados += c })
    req.on('end', () => { try { resolve(JSON.parse(dados || '{}')) } catch { resolve({}) } })
  })
}

http.createServer(async (req, res) => {
  if (req.method === 'POST' && req.url === '/send') {
    const { jid, text } = await lerCorpo(req)
    if (!conectado || !sock) { res.writeHead(503); return res.end('WhatsApp desconectado') }
    if (!jid || !text) { res.writeHead(400); return res.end('jid e text são obrigatórios') }
    try {
      await sock.sendMessage(jid, { text })
      res.writeHead(200); return res.end('ok')
    } catch (erro) {
      console.log(`[${hora()}] Falha ao enviar para ${jid}: ${erro.message}`)
      res.writeHead(500); return res.end('falha ao enviar')
    }
  }
  if (req.url === '/qr.json') {
    const qr = !conectado && qrAtual ? await QRCode.toDataURL(qrAtual, { width: 320, margin: 2 }) : null
    res.writeHead(200, { 'Content-Type': 'application/json' })
    return res.end(JSON.stringify({ conectado, qr }))
  }
  if (req.method === 'POST' && req.url === '/desligar') {
    res.writeHead(200); res.end('ok')
    console.log(`[${hora()}] Desligando a ponte a pedido do painel.`)
    return setTimeout(() => process.exit(0), 300)
  }
  if (req.url === '/status') {
    res.writeHead(200, { 'Content-Type': 'application/json' })
    return res.end(JSON.stringify({ conectado }))
  }
  let corpo
  if (conectado) {
    corpo = '<h2>✅ WhatsApp conectado</h2><p>O bot está funcionando. Pode fechar esta página.</p>'
  } else if (qrAtual) {
    const img = await QRCode.toDataURL(qrAtual, { width: 320, margin: 2 })
    corpo = `<h2>Escaneie com o WhatsApp Business da biblioteca</h2>
      <p>No celular: Aparelhos conectados &gt; Conectar um aparelho</p>
      <img src="${img}" alt="QR code"><p>O código se renova sozinho.</p>`
  } else {
    corpo = '<h2>Conectando ao WhatsApp...</h2>'
  }
  res.writeHead(200, { 'Content-Type': 'text/html; charset=utf-8' })
  res.end(`<!DOCTYPE html><html lang="pt-BR"><head><meta charset="utf-8">
    <meta http-equiv="refresh" content="5"><title>BEESC BOT</title></head>
    <body style="font-family:system-ui,sans-serif;text-align:center;padding:2rem">${corpo}</body></html>`)
}).listen(PORTA, '127.0.0.1', () => {
  console.log(`[${hora()}] Ponte do WhatsApp rodando. Painel: http://localhost:${PORTA}`)
})

conectar()
