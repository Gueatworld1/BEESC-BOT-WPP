"""Banco de dados do bot: mensagens do menu, configurações, contatos e atividade.

As mensagens e o horário são editados pelo painel (atalho "BEESC BOT").
Com vários computadores, o banco fica numa pasta compartilhada da rede, definida
no painel (Ajustes > Vários computadores) e guardada em local.json.
Este arquivo guarda só os textos PADRÃO, usados na primeira instalação ou ao
restaurar:  py -3 criar_banco.py --restaurar
"""
import json, os, sqlite3, sys

PASTA = os.path.dirname(os.path.abspath(__file__))
BANCO_LOCAL = os.path.join(PASTA, "respostas.db")
ARQ_LOCAL = os.path.join(PASTA, "local.json")    # configuração só deste computador
VERSAO_BANCO = 3

# ====== MENU DE BOAS-VINDAS (padrão) ======
MENU = """Olá! Bem-vindo(a) à Biblioteca da Escola de Engenharia de São Carlos (EESC-USP). 📚

Para agilizar seu atendimento, digite *apenas o número* do que você precisa:

1. Empréstimo e Reserva de Livros
2. Ficha Catalográfica
3. Solicitação de Artigos e Empréstimos entre Bibliotecas (EEB)
4. Reserva da Sala Multiuso
5. Acesso ao Turnitin
6. Doação de Livros
7. Achados e Perdidos
8. Informações sobre Cursos da EESC
9. Consultar se um livro está disponível

👤 Para falar com a equipe ou outros assuntos, digite *atendimento*.

_Para ver este menu de novo, digite *menu*._"""

# ====== RESPOSTAS (padrão) ======
# (gatilho, texto, acao)
#   acao 0 = só responde
#   acao 1 = responde e pausa o bot, para a equipe atender
#   acao 2 = responde e trata a próxima mensagem como busca de livro no Dedalus
RESPOSTAS = [
    ("menu", MENU, 0),

    ("1", """📖 *Empréstimos e Reservas*
O empréstimo é restrito à comunidade da USP. Para realizá-lo, é imprescindível apresentar o cartão USP (físico ou digital) no balcão de atendimento.

A reserva de livros pode ser feita pelo aplicativo das bibliotecas USP ou pelos sites:
🔗 https://dedalus.usp.br
🔗 https://www.buscaintegrada.usp.br""", 0),

    ("2", """📇 *Ficha Catalográfica*
Você pode elaborar a ficha catalográfica diretamente pelo link:
🔗 https://sistemas-biblioteca.eesc.usp.br/fichacatalografica

Caso prefira, ou se o trabalho for em inglês, você pode solicitar a ficha pelo e-mail: biblioteca@eesc.usp.br""", 0),

    ("3", """📄 *Artigos e Empréstimos entre Bibliotecas*

• *Solicitação de Artigos:* preencha o formulário no nosso site: https://eesc.usp.br/biblioteca/post.php?guid=115&catid=servicos
(Dúvidas: biblioteca.documentos@eesc.usp.br)

• *Empréstimo Entre Bibliotecas (EEB):* a solicitação é feita via Sisweeb: https://www.iqsc.usp.br/eeb/index.php
Você será avisado(a) quando o livro chegar.""", 0),

    ("4", """🔑 *Reserva da Sala Multiuso*
Para solicitar, nos envie por aqui: finalidade da reserva, quantidade de pessoas, seu nome completo, Nº USP, telefone/e-mail, além da data e hora desejadas. Verificaremos a disponibilidade e confirmaremos em seguida.

⚠️ *Regras:* não é permitido ausentar-se por muito tempo; avise com antecedência se for cancelar; devolva chaves/kits no balcão após o uso. O solicitante é responsável pela conservação do local.

_Para voltar ao menu, digite *menu*._""", 1),

    ("5", """💻 *Acesso ao Turnitin*
Para solicitar acesso, preencha o formulário disponível neste link:
🔗 https://eesc.usp.br/biblioteca/post.php?guid=49&catid=fontes

Assim que preenchido, iremos autorizar o uso e você receberá um e-mail do Turnitin com as instruções de acesso.""", 0),

    ("6", """📚 *Doação de Livros*
Ficamos felizes com o seu interesse! Para doar, por favor, envie uma lista dos livros para o e-mail:
✉️ biblioteca.tratamento@eesc.usp.br""", 0),

    ("7", """🔍 *Achados e Perdidos*
Temos um espaço de achados e perdidos aqui na seção de atendimento da biblioteca da EESC. Você deverá vir pessoalmente ao balcão para verificar se o seu objeto está conosco.""", 0),

    ("8", """🎓 *Cursos da EESC*
Todas as informações sobre os cursos de graduação podem ser encontradas neste link:
🔗 https://eesc.usp.br/graduacao""", 0),

    ("atendimento", """👤 Um de nossos atendentes já vai falar com você. Por favor, deixe sua dúvida ou solicitação digitada abaixo:

_Para voltar ao menu, digite *menu*._""", 1),

    ("9", """🔎 *Consulta de livros*
Digite o título e o autor do livro que você procura. Se quiser, inclua a edição e o volume.

Exemplo: _Cálculo Stewart 5ª edição volume 2_

Vou verificar a disponibilidade nas bibliotecas da USP em São Carlos.""", 2),
]

# ====== CONFIGURAÇÕES (padrão) ======
CONFIG_PADRAO = {
    # dia da semana ("0" = segunda ... "6" = domingo): [abre, fecha] em horas (8.5 = 08:30); dia ausente = fechado
    "horario": {"0": [8, 22], "1": [8, 22], "2": [8, 22], "3": [8, 22], "4": [8, 22]},
    "aviso_fora": "⏰ No momento estamos fora do horário de atendimento. Sua mensagem será respondida assim que retomarmos.",
    "janela_horas": 12,   # sem escrever há mais que isso = conversa nova, recebe o menu
    "pausa_horas": 12,    # silêncio do bot depois das opções com acao = 1
    "busca_min": 10,      # depois da busca de livros, quanto tempo a próxima mensagem vale como busca
}


def config_local():
    try:
        with open(ARQ_LOCAL, encoding="utf-8") as f:
            return json.load(f)
    except (OSError, ValueError):
        return {}


def salvar_config_local(dados):
    with open(ARQ_LOCAL, "w", encoding="utf-8") as f:
        json.dump(dados, f, ensure_ascii=False, indent=2)


def pasta_compartilhada():
    return config_local().get("pasta_compartilhada") or None


def caminho_banco():
    """Banco compartilhado (se configurado e acessível) ou o banco local deste computador."""
    pasta = pasta_compartilhada()
    if pasta and os.path.isdir(pasta):
        return os.path.join(pasta, "beesc-bot.db")
    return BANCO_LOCAL


def compartilhado_ok():
    pasta = pasta_compartilhada()
    return None if not pasta else os.path.isdir(pasta)


def conectar():
    # timeout maior: numa pasta de rede, outro computador pode estar gravando ao mesmo tempo
    return sqlite3.connect(caminho_banco(), timeout=20)


def _gravar_padrao(con):
    con.execute("DROP TABLE IF EXISTS respostas")
    con.execute("CREATE TABLE respostas (gatilho TEXT PRIMARY KEY, resposta TEXT, acao INTEGER, ordem INTEGER)")
    con.executemany("INSERT INTO respostas VALUES (?, ?, ?, ?)",
                    [(g, t, a, n) for n, (g, t, a) in enumerate(RESPOSTAS)])


def garantir_banco():
    """Cria o que faltar. Não apaga nada que já foi editado pelo painel."""
    con = conectar()
    con.execute("CREATE TABLE IF NOT EXISTS contatos (jid TEXT PRIMARY KEY, ultima_msg REAL, pausado_ate REAL)")
    for comando in ("ALTER TABLE contatos ADD COLUMN busca_ate REAL DEFAULT 0",
                    "ALTER TABLE contatos ADD COLUMN nome TEXT DEFAULT ''"):
        try:
            con.execute(comando)
        except sqlite3.OperationalError:
            pass
    con.execute("CREATE TABLE IF NOT EXISTS atividade (ts REAL, jid TEXT, nome TEXT, tipo TEXT, detalhe TEXT)")
    try:
        con.execute("ALTER TABLE atividade ADD COLUMN pc TEXT DEFAULT ''")
    except sqlite3.OperationalError:
        pass
    con.execute("CREATE INDEX IF NOT EXISTS atividade_ts ON atividade (ts)")
    con.execute("CREATE INDEX IF NOT EXISTS atividade_jid ON atividade (jid)")
    con.execute("CREATE TABLE IF NOT EXISTS config (chave TEXT PRIMARY KEY, valor TEXT)")
    # qual computador está respondendo (uma linha só) e mensagens já respondidas (evita duplicar)
    con.execute("CREATE TABLE IF NOT EXISTS lider (id INTEGER PRIMARY KEY CHECK (id = 1), pc TEXT, contador INTEGER, ts REAL)")
    con.execute("CREATE TABLE IF NOT EXISTS processadas (msg_id TEXT PRIMARY KEY, ts REAL)")
    con.execute("CREATE TABLE IF NOT EXISTS computadores (pc TEXT PRIMARY KEY, visto REAL, versao TEXT)")
    versao = con.execute("SELECT valor FROM config WHERE chave = 'versao_banco'").fetchone()
    if not versao:
        # banco de uma versão sem painel: as mensagens vinham deste arquivo, então são regravadas
        _gravar_padrao(con)
    for chave, valor in CONFIG_PADRAO.items():
        con.execute("INSERT OR IGNORE INTO config VALUES (?, ?)", (chave, json.dumps(valor, ensure_ascii=False)))
    con.execute("INSERT OR REPLACE INTO config VALUES ('versao_banco', ?)", (str(VERSAO_BANCO),))
    con.commit()
    con.close()


def restaurar_padrao():
    con = conectar()
    _gravar_padrao(con)
    for chave, valor in CONFIG_PADRAO.items():
        con.execute("INSERT OR REPLACE INTO config VALUES (?, ?)", (chave, json.dumps(valor, ensure_ascii=False)))
    con.commit()
    con.close()


if __name__ == "__main__":
    if "--restaurar" in sys.argv:
        if input("Isso volta todas as mensagens e o horário ao padrão. Confirmar? (s/n) ").lower().startswith("s"):
            restaurar_padrao()
            print(f"{len(RESPOSTAS)} mensagens restauradas.")
    else:
        garantir_banco()
        print("Banco pronto.")
