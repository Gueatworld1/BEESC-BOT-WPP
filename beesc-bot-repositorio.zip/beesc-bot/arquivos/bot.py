"""Bot de WhatsApp da Biblioteca EESC + painel de controle (http://127.0.0.1:5000).

Recebe as mensagens da ponte (ponte.js), decide a resposta e serve o painel
onde a equipe edita mensagens, horário e acompanha o atendimento.
"""
import json, logging, os, platform, re, sqlite3, subprocess, sys, threading, time, unicodedata, requests
from datetime import datetime
from flask import Flask, request, jsonify, send_from_directory, redirect
import dedalus, criar_banco

PONTE = "http://127.0.0.1:3000"
PASTA = os.path.dirname(os.path.abspath(__file__))
VERSAO = "3.0"
PC = (os.environ.get("COMPUTERNAME") or platform.node() or "PC").upper()
LIDER_SEG = 45          # sem sinal do computador ativo por esse tempo = outro assume

app = Flask(__name__, static_folder=None)
logging.getLogger("werkzeug").setLevel(logging.ERROR)   # não encher o bot.log com cada acesso ao painel
criar_banco.garantir_banco()
estado = {"ativo": True, "lider": PC, "visto_contador": None, "visto_em": 0, "erro": None}


# ---------------------------------------------------------------- vários computadores
def atualizar_lider(forcar=False):
    """Só um computador responde de cada vez. Quem está ativo incrementa um contador no
    banco compartilhado a cada 10 s. Se o contador ficar parado por LIDER_SEG segundos
    (medidos no relógio deste computador), o ativo caiu e este assume."""
    if not criar_banco.pasta_compartilhada():
        estado.update(ativo=True, lider=PC, erro=None)       # um computador só: sempre ativo
        return
    if not criar_banco.compartilhado_ok():
        # pasta de rede fora do ar: responde assim mesmo (melhor que ninguém responder)
        estado.update(ativo=True, lider=PC, erro="Pasta compartilhada inacessível; respondendo sozinho.")
        return
    con = criar_banco.conectar()
    con.isolation_level = None
    try:
        con.execute("BEGIN IMMEDIATE")
        linha = con.execute("SELECT pc, contador FROM lider WHERE id = 1").fetchone()
        agora = time.time()
        if linha and linha[1] != estado["visto_contador"]:
            estado.update(visto_contador=linha[1], visto_em=agora)
        parado = agora - estado["visto_em"] > LIDER_SEG
        if forcar or not linha or linha[0] == PC or parado:
            contador = (linha[1] if linha else 0) + 1
            con.execute("INSERT OR REPLACE INTO lider VALUES (1, ?, ?, ?)", (PC, contador, agora))
            estado.update(ativo=True, lider=PC, visto_contador=contador, visto_em=agora)
            if linha and linha[0] != PC:
                print(f"[{datetime.now():%H:%M:%S}] Este computador assumiu o atendimento (antes: {linha[0]}).", flush=True)
        else:
            if estado["ativo"]:
                print(f"[{datetime.now():%H:%M:%S}] {linha[0]} está atendendo; este computador fica em espera.", flush=True)
            estado.update(ativo=False, lider=linha[0])
        con.execute("INSERT OR REPLACE INTO computadores VALUES (?, ?, ?)", (PC, agora, VERSAO))
        con.execute("DELETE FROM processadas WHERE ts < ?", (agora - 86400,))
        con.execute("COMMIT")
        estado["erro"] = None
    except sqlite3.Error as erro:
        try:
            con.execute("ROLLBACK")
        except sqlite3.Error:
            pass
        estado["erro"] = f"Erro no banco compartilhado: {erro}"
    finally:
        con.close()


def ciclo_lider():
    while True:
        try:
            atualizar_lider()
        except Exception as erro:
            estado["erro"] = str(erro)
        time.sleep(10)


def primeira_vez(msg_id):
    """Marca a mensagem como respondida no banco. Se outro computador já marcou, devolve False."""
    if not msg_id:
        return True
    con = criar_banco.conectar()
    try:
        con.execute("INSERT INTO processadas VALUES (?, ?)", (msg_id, time.time()))
        con.commit()
        return True
    except sqlite3.IntegrityError:
        return False
    finally:
        con.close()


# ---------------------------------------------------------------- utilidades
def normalizar(texto):
    t = unicodedata.normalize("NFKD", texto or "").encode("ascii", "ignore").decode()
    t = re.sub(r"[^\w\s]", "", t)
    return " ".join(t.lower().split())


def config():
    cfg = dict(criar_banco.CONFIG_PADRAO)
    con = criar_banco.conectar()
    for chave, valor in con.execute("SELECT chave, valor FROM config"):
        try:
            cfg[chave] = json.loads(valor)
        except ValueError:
            pass
    con.close()
    return cfg


def dentro_do_horario(cfg):
    agora = datetime.now()
    h = cfg["horario"].get(str(agora.weekday()))
    hora = agora.hour + agora.minute / 60          # 8.5 = 08:30
    return bool(h) and float(h[0]) <= hora < float(h[1])


def registrar(jid, nome, tipo, detalhe=""):
    con = criar_banco.conectar()
    con.execute("INSERT INTO atividade (ts, jid, nome, tipo, detalhe, pc) VALUES (?, ?, ?, ?, ?, ?)",
                (time.time(), jid, nome or "", tipo, detalhe[:200], PC))
    if nome:
        con.execute("UPDATE contatos SET nome = ? WHERE jid = ?", (nome, jid))
    con.execute("DELETE FROM atividade WHERE ts < ?", (time.time() - 400 * 86400,))   # guarda ~1 ano
    con.commit()
    con.close()


def enviar(jid, texto):
    try:
        r = requests.post(f"{PONTE}/send", json={"jid": jid, "text": texto}, timeout=30)
        print(f"[{datetime.now():%H:%M:%S}] Enviado para {jid} (status {r.status_code})", flush=True)
    except requests.RequestException:
        print("A ponte do WhatsApp não respondeu. Ela está aberta?", flush=True)


def buscar_livro(jid, nome, pedido):
    try:
        enviar(jid, dedalus.buscar(pedido))
    except Exception as erro:
        print("Erro na busca do Dedalus:", erro, flush=True)
        enviar(jid, "Não consegui consultar o catálogo agora. Tente em https://dedalus.usp.br "
                    "ou digite *atendimento* para falar com a equipe.")


# ---------------------------------------------------------------- WhatsApp
@app.post("/webhook")
def webhook():
    d = (request.get_json(silent=True) or {}).get("data", {})
    chave = d.get("key", {})
    jid = chave.get("remoteJid", "")
    if chave.get("fromMe") or jid.endswith("@g.us") or jid == "status@broadcast":
        return "ok"
    if not estado["ativo"]:
        return "ok"                      # outro computador está atendendo
    if not primeira_vez(chave.get("id")):
        return "ok"                      # outro computador já respondeu esta mensagem

    nome = d.get("pushName", "")
    msg = d.get("message") or {}
    original = msg.get("conversation") or msg.get("extendedTextMessage", {}).get("text", "")
    texto = normalizar(original)
    agora = time.time()
    cfg = config()

    con = criar_banco.conectar()
    linha = con.execute("SELECT ultima_msg, pausado_ate, busca_ate FROM contatos WHERE jid = ?", (jid,)).fetchone()
    ultima_msg, pausado_ate, busca_ate = linha if linha else (0, 0, 0)
    con.execute("INSERT OR REPLACE INTO contatos (jid, ultima_msg, pausado_ate, busca_ate, nome) VALUES (?, ?, ?, ?, ?)",
                (jid, agora, pausado_ate, busca_ate, nome))

    pediu_menu = texto in ("menu", "0")
    conversa_nova = agora - ultima_msg > cfg["janela_horas"] * 3600
    em_pausa = (pausado_ate or 0) > agora
    aguardando_busca = (busca_ate or 0) > agora

    opcao = con.execute("SELECT resposta, acao FROM respostas WHERE gatilho = ?", (texto,)).fetchone()
    menu = con.execute("SELECT resposta FROM respostas WHERE gatilho = 'menu'").fetchone()
    evento = None

    if pediu_menu or (conversa_nova and not em_pausa):
        if menu:
            enviar(jid, menu[0])
        con.execute("UPDATE contatos SET pausado_ate = 0, busca_ate = 0 WHERE jid = ?", (jid,))
        evento = ("menu", "")
    elif opcao and not em_pausa:
        resposta, acao = opcao
        if acao == 1 and not dentro_do_horario(cfg):
            resposta += "\n\n" + cfg["aviso_fora"]
        enviar(jid, resposta)
        if acao == 1:
            con.execute("UPDATE contatos SET pausado_ate = ? WHERE jid = ?", (agora + cfg["pausa_horas"] * 3600, jid))
            evento = ("equipe", texto)
        elif acao == 2:
            con.execute("UPDATE contatos SET busca_ate = ? WHERE jid = ?", (agora + cfg["busca_min"] * 60, jid))
            evento = ("opcao", texto)
        else:
            evento = ("opcao", texto)
    elif aguardando_busca and texto and not em_pausa:
        con.execute("UPDATE contatos SET busca_ate = 0 WHERE jid = ?", (jid,))
        enviar(jid, "🔎 Consultando o catálogo, só um instante...")
        threading.Thread(target=buscar_livro, args=(jid, nome, original), daemon=True).start()
        evento = ("busca", original)
    elif not em_pausa:
        evento = ("sem_resposta", "")
    con.commit()
    con.close()
    if evento:
        registrar(jid, nome, *evento)
    return "ok"


# ---------------------------------------------------------------- painel
@app.get("/")
def inicio():
    return redirect("/painel/")


@app.get("/painel/")
@app.get("/painel/<path:arquivo>")
def painel(arquivo="index.html"):
    return send_from_directory(os.path.join(PASTA, "painel"), arquivo)


@app.get("/api/ping")
def ping():
    return "ok"


@app.get("/api/status")
def status():
    whatsapp = {"conectado": False, "qr": None, "ponte": False}
    try:
        whatsapp.update(requests.get(f"{PONTE}/qr.json", timeout=3).json(), ponte=True)
    except (requests.RequestException, ValueError):
        pass
    inicio_dia = datetime.now().replace(hour=0, minute=0, second=0).timestamp()
    con = criar_banco.conectar()
    hoje = dict(con.execute("SELECT tipo, COUNT(*) FROM atividade WHERE ts >= ? GROUP BY tipo", (inicio_dia,)).fetchall())
    pessoas = con.execute("SELECT COUNT(DISTINCT jid) FROM atividade WHERE ts >= ?", (inicio_dia,)).fetchone()[0]
    con.close()
    multi = {"pc": PC, "ativo": estado["ativo"], "lider": estado["lider"], "erro": estado["erro"],
             "pasta": criar_banco.pasta_compartilhada(), "computadores": []}
    if multi["pasta"] and criar_banco.compartilhado_ok():
        con = criar_banco.conectar()
        multi["computadores"] = [{"pc": p, "online": time.time() - v < 90, "versao": ver}
                                 for p, v, ver in con.execute("SELECT pc, visto, versao FROM computadores ORDER BY pc")]
        con.close()
    return jsonify(versao=VERSAO, whatsapp=whatsapp, multi=multi, horario_atendimento=dentro_do_horario(config()),
                   hoje={"pessoas": pessoas, "respostas": hoje.get("opcao", 0) + hoje.get("menu", 0),
                         "buscas": hoje.get("busca", 0), "equipe": hoje.get("equipe", 0)})


@app.get("/api/respostas")
def ler_respostas():
    con = criar_banco.conectar()
    linhas = con.execute("SELECT gatilho, resposta, acao FROM respostas ORDER BY gatilho != 'menu', ordem").fetchall()
    con.close()
    return jsonify([{"gatilho": g, "texto": t, "acao": a} for g, t, a in linhas])


@app.post("/api/respostas")
def salvar_respostas():
    itens = request.get_json(silent=True) or []
    vistos, limpos = set(), []
    for item in itens:
        g = normalizar(str(item.get("gatilho", "")))
        texto = str(item.get("texto", "")).strip()
        if not g or not texto:
            return jsonify(erro="Toda resposta precisa de um gatilho e de um texto."), 400
        if g in vistos:
            return jsonify(erro=f"O gatilho “{g}” aparece mais de uma vez."), 400
        vistos.add(g)
        limpos.append((g, texto, int(item.get("acao", 0)) if str(item.get("acao", 0)) in "012" else 0))
    if "menu" not in vistos:
        return jsonify(erro="O menu de boas-vindas não pode ser removido."), 400
    con = criar_banco.conectar()
    con.execute("DELETE FROM respostas")
    con.executemany("INSERT INTO respostas VALUES (?, ?, ?, ?)", [(g, t, a, n) for n, (g, t, a) in enumerate(limpos)])
    con.commit()
    con.close()
    return jsonify(ok=True, total=len(limpos))


@app.get("/api/config")
def ler_config():
    return jsonify(config())


@app.post("/api/config")
def salvar_config():
    novo = request.get_json(silent=True) or {}
    con = criar_banco.conectar()
    for chave in criar_banco.CONFIG_PADRAO:
        if chave in novo:
            con.execute("INSERT OR REPLACE INTO config VALUES (?, ?)", (chave, json.dumps(novo[chave], ensure_ascii=False)))
    con.commit()
    con.close()
    return jsonify(ok=True)


@app.post("/api/restaurar")
def restaurar():
    criar_banco.restaurar_padrao()
    return jsonify(ok=True)


@app.post("/api/busca")
def testar_busca():
    pedido = (request.get_json(silent=True) or {}).get("pedido", "")
    try:
        return jsonify(texto=dedalus.buscar(pedido))
    except Exception as erro:
        return jsonify(erro=f"Não consegui consultar o Dedalus: {erro}"), 502


@app.get("/api/atividade")
def atividade():
    con = criar_banco.conectar()
    linhas = con.execute("SELECT ts, jid, nome, tipo, detalhe, pc FROM atividade ORDER BY ts DESC LIMIT 150").fetchall()
    con.close()
    return jsonify([{"ts": ts, "contato": nome or jid.split("@")[0][-4:].rjust(8, "•"), "tipo": tipo, "detalhe": det, "pc": pc or ""}
                    for ts, jid, nome, tipo, det, pc in linhas])


@app.post("/api/contato/liberar")
def liberar_pausas():
    con = criar_banco.conectar()
    con.execute("UPDATE contatos SET pausado_ate = 0, busca_ate = 0")
    con.commit()
    con.close()
    return jsonify(ok=True)


@app.get("/api/logs")
def logs():
    saida = {}
    for nome in ("bot.log", "ponte.log"):
        try:
            with open(os.path.join(PASTA, nome), encoding="utf-8", errors="replace") as f:
                saida[nome] = "".join(f.readlines()[-60:])
        except OSError:
            saida[nome] = "(sem registro)"
    return jsonify(saida)


@app.post("/api/ativar")
def ativar_aqui():
    atualizar_lider(forcar=True)
    return jsonify(ok=True, ativo=estado["ativo"])


@app.post("/api/compartilhar")
def compartilhar():
    """Liga (pasta preenchida) ou desliga (pasta vazia) o banco compartilhado."""
    import shutil
    pasta = ((request.get_json(silent=True) or {}).get("pasta") or "").strip().strip('"')
    local = criar_banco.config_local()
    if not pasta:
        atual = criar_banco.caminho_banco()
        if atual != criar_banco.BANCO_LOCAL and os.path.exists(atual):
            shutil.copy2(atual, criar_banco.BANCO_LOCAL)    # leva uma cópia dos dados para este PC
        local.pop("pasta_compartilhada", None)
        criar_banco.salvar_config_local(local)
        atualizar_lider()
        return jsonify(ok=True, msg="Este computador voltou a usar só o banco local.")
    if not os.path.isdir(pasta):
        return jsonify(erro="Não encontrei essa pasta. Confira o caminho e se este computador tem acesso a ela."), 400
    destino = os.path.join(pasta, "beesc-bot.db")
    try:
        teste = os.path.join(pasta, f".teste-{PC}")
        open(teste, "w").close()
        os.remove(teste)
    except OSError:
        return jsonify(erro="Este computador não tem permissão para gravar nessa pasta."), 400
    if not os.path.exists(destino):
        shutil.copy2(criar_banco.caminho_banco(), destino)  # primeiro computador: leva os dados atuais
        msg = "Pasta configurada. Os dados deste computador foram copiados para ela."
    else:
        msg = "Pasta configurada. Este computador passou a usar o banco que já estava lá."
    local["pasta_compartilhada"] = pasta
    criar_banco.salvar_config_local(local)
    criar_banco.garantir_banco()
    atualizar_lider()
    return jsonify(ok=True, msg=msg)


def _formatar_numero(jid):
    n = jid.split("@")[0]
    if not jid.endswith("@s.whatsapp.net") or not n.isdigit():
        return ""
    if n.startswith("55") and len(n) in (12, 13):
        return f"+55 ({n[2:4]}) {n[4:-4]}-{n[-4:]}"
    return "+" + n


@app.get("/api/pessoas")
def pessoas():
    con = criar_banco.conectar()
    linhas = con.execute("""
        SELECT a.jid, COALESCE(NULLIF(MAX(c.nome), ''), MAX(a.nome)) AS nome,
               COUNT(DISTINCT date(a.ts, 'unixepoch', 'localtime')) AS dias,
               SUM(a.tipo IN ('menu', 'opcao', 'busca', 'equipe', 'sem_resposta')) AS mensagens,
               SUM(a.tipo = 'busca') AS buscas, SUM(a.tipo = 'equipe') AS equipe,
               MIN(a.ts) AS primeira, MAX(a.ts) AS ultima
        FROM atividade a LEFT JOIN contatos c ON c.jid = a.jid
        GROUP BY a.jid ORDER BY ultima DESC""").fetchall()
    total = con.execute("SELECT COUNT(DISTINCT jid), COUNT(*), SUM(tipo = 'busca'), SUM(tipo = 'equipe') FROM atividade").fetchone()
    por_pc = con.execute("SELECT COALESCE(NULLIF(pc, ''), '—'), COUNT(*) FROM atividade GROUP BY 1 ORDER BY 2 DESC").fetchall()
    con.close()
    return jsonify(
        pessoas=[{"jid": j, "nome": n or "", "numero": _formatar_numero(j), "dias": d, "mensagens": m or 0,
                  "buscas": b or 0, "equipe": e or 0, "primeira": p, "ultima": u}
                 for j, n, d, m, b, e, p, u in linhas],
        total={"pessoas": total[0] or 0, "eventos": total[1] or 0, "buscas": total[2] or 0, "equipe": total[3] or 0},
        por_computador=[{"pc": p, "eventos": n} for p, n in por_pc])


def _encerrar(reiniciar):
    try:
        requests.post(f"{PONTE}/desligar", timeout=3)
    except requests.RequestException:
        pass
    if reiniciar and sys.platform == "win32":
        subprocess.Popen(["wscript", os.path.join(PASTA, "iniciar_oculto.vbs"), "/aguardar"],
                         creationflags=0x00000008, close_fds=True)   # DETACHED_PROCESS
    threading.Timer(0.8, lambda: os._exit(0)).start()


@app.post("/api/reiniciar")
def reiniciar():
    _encerrar(True)
    return jsonify(ok=True)


@app.post("/api/desligar")
def desligar():
    _encerrar(False)
    return jsonify(ok=True)


if __name__ == "__main__":
    atualizar_lider()
    threading.Thread(target=ciclo_lider, daemon=True).start()
    print(f"[{datetime.now():%H:%M:%S}] Bot iniciado. Painel: http://127.0.0.1:5000", flush=True)
    app.run(host="127.0.0.1", port=5000)
