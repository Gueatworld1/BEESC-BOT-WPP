' Abre o painel do bot como um aplicativo. Se o bot estiver desligado, liga antes.
Set sh = CreateObject("WScript.Shell")
pasta = CreateObject("Scripting.FileSystemObject").GetParentFolderName(WScript.ScriptFullName)
url = "http://127.0.0.1:5000/"
If Not BotRodando() Then
  sh.Run "cmd /c """ & pasta & "\iniciar_bot.bat""", 0, False
  For i = 1 To 30
    WScript.Sleep 1000
    If BotRodando() Then Exit For
  Next
End If
On Error Resume Next
sh.Run "msedge --app=" & url & " --window-size=1180,820", 1, False
If Err.Number <> 0 Then
  Err.Clear
  sh.Run url, 1, False
End If

Function BotRodando()
  On Error Resume Next
  Set x = CreateObject("MSXML2.ServerXMLHTTP.6.0")
  x.setTimeouts 2000, 2000, 2000, 2000
  x.Open "GET", "http://127.0.0.1:5000/api/ping", False
  x.Send
  BotRodando = (Err.Number = 0 And x.Status = 200)
End Function
