# Arquitetura

## Caminho de uma mensagem

1. A **ponte** (`ponte.js`) está conectada ao WhatsApp como aparelho conectado e recebe a mensagem.
2. Ela repassa a mensagem ao **bot** em `http://127.0.0.1:5000/webhook`.
3. O bot verifica se este computador está **ativo** (vários computadores) e registra o código da mensagem na tabela `processadas`. Se outro computador já registrou, não responde.
4. O bot consulta o banco e decide:
   - primeira mensagem do contato, ou mais de 12 h sem falar → menu;
   - número de uma opção → resposta daquela opção;
   - opção com ação “chamar a equipe” → resposta e pausa de 12 h para aquele contato;
   - opção com ação “buscar livro” → a próxima mensagem vira consulta no Dedalus;
   - qualquer outra coisa → silêncio (fica para a equipe).
5. O bot pede à ponte que envie a resposta (`http://127.0.0.1:3000/send`).

## Banco de dados (SQLite)

| Tabela | Conteúdo |
|---|---|
| `respostas` | Gatilho, texto e ação de cada opção do menu (editado pelo painel). |
| `config` | Horário de atendimento, aviso fora do horário, tempos de janela/pausa/busca. |
| `contatos` | Última mensagem, pausa e estado de busca de cada contato. |
| `atividade` | Histórico de ~1 ano (quem, quando, o que, qual computador). Base das estatísticas. |
| `lider` | Qual computador está respondendo e o contador de sinal de vida. |
| `processadas` | Códigos das mensagens já respondidas nas últimas 24 h (evita duplicar). |
| `computadores` | Computadores que usam o banco compartilhado e quando foram vistos. |

Com um computador só, o banco é `respostas.db` na pasta do bot. Com vários, é `beesc-bot.db` na pasta compartilhada (caminho guardado em `local.json`).

## Vários computadores

O computador ativo incrementa `lider.contador` a cada 10 s, dentro de uma transação `BEGIN IMMEDIATE` (o SQLite garante que só um grava por vez). Os outros observam o contador; se ele ficar parado por 45 s, medidos no relógio de quem observa (imune a relógios diferentes entre PCs), o primeiro a perceber assume. Se a pasta compartilhada ficar inacessível, o computador responde sozinho e o painel mostra um aviso.

## Busca no Dedalus (`dedalus.py`)

1. Interpreta o pedido: termos, edição (“5ª ed.”, “edição 5”) e volume (“v. 2”, “cálculo 2”).
2. Descobre no formulário do Dedalus os códigos das bases de São Carlos e do filtro “Livros” (feito uma vez por execução).
3. Busca primeiro na base da EESC. Para cada título, a página de exemplares já vem filtrada pela EESC; o filtro “Sub-biblioteca” da mesma página informa quais bibliotecas têm o livro.
4. Se a EESC não tem disponível, busca nas outras bases de São Carlos ao mesmo tempo.
5. Se nada é encontrado em São Carlos, consulta o catálogo geral só para dizer em quais bibliotecas o livro está.

Os títulos são consultados em paralelo (4 sessões do Dedalus reaproveitadas por 8 minutos), e a busca para assim que encontra o suficiente.
